// ====== CẤU HÌNH ======
const MA_SINH_VIEN = "MÃ SV CỦA BẠN"; // thay bằng mã sinh viên thật của bạn
const MOVE_INTERVAL = 1000;           // mục tiêu tự đổi vị trí sau mỗi 1000ms (1 giây)

// ====== LẤY CÁC PHẦN TỬ TRÊN TRANG ======
const arena = document.getElementById('arena');          // khu vực chơi
const target = document.getElementById('target');        // mục tiêu (hình tròn)
const overlay = document.getElementById('overlay');      // lớp phủ hiển thị kết quả
const scoreEl = document.getElementById('score');       // chỗ hiển thị điểm
const timeEl = document.getElementById('time');         // chỗ hiển thị thời gian còn lại
const timeInput = document.getElementById('timeInput');  // ô nhập thời gian tùy chọn
const startBtn = document.getElementById('startBtn');    // nút bắt đầu
const colorBtn = document.getElementById('colorBtn');    // nút đổi màu nền
const playerBtn = document.getElementById('playerBtn');  // nút người chơi
const playerInfo = document.getElementById('playerInfo');// chỗ hiện mã sinh viên

// ====== BIẾN TRẠNG THÁI ======
let score = 0;          // điểm hiện tại
let timeLeft = 0;       // số giây còn lại
let running = false;    // true khi trò chơi đang chạy
let countdownId = null; // id của bộ đếm ngược 1 giây
let moveId = null;      // id của bộ đếm đổi vị trí mục tiêu

// Đặt mục tiêu ở vị trí top/left ngẫu nhiên trong arena
function moveTarget() {
  const maxLeft = arena.clientWidth - target.offsetWidth;   // left lớn nhất để mục tiêu không tràn
  const maxTop = arena.clientHeight - target.offsetHeight;  // top lớn nhất
  target.style.left = Math.floor(Math.random() * (maxLeft + 1)) + 'px'; // left ngẫu nhiên
  target.style.top = Math.floor(Math.random() * (maxTop + 1)) + 'px';   // top ngẫu nhiên
}

// Khởi động lại bộ đếm 1 giây để mục tiêu tự đổi vị trí
function restartMoveTimer() {
  clearInterval(moveId);                          // xóa bộ đếm cũ
  moveId = setInterval(moveTarget, MOVE_INTERVAL); // tạo bộ đếm mới
}

// Bật/tắt các nút khi chơi hoặc khi hết giờ
function setControlsLocked(locked) {
  startBtn.disabled = locked;   // khóa nút bắt đầu khi đang chơi
  timeInput.disabled = locked;  // khóa ô nhập thời gian khi đang chơi
}

// Bắt đầu trò chơi
function startGame() {
  let seconds = parseInt(timeInput.value, 10); // đọc thời gian người chơi chọn
  if (isNaN(seconds) || seconds < 1) seconds = 30; // sai/không nhập thì dùng 30 giây
  timeLeft = seconds;                          // gán thời gian còn lại
  score = 0;                                   // đặt lại điểm về 0
  running = true;                              // đánh dấu đang chơi
  scoreEl.textContent = score;                 // hiển thị điểm
  timeEl.textContent = timeLeft;               // hiển thị thời gian
  overlay.style.display = 'none';              // ẩn bảng kết quả cũ
  target.style.display = 'block';              // hiện mục tiêu
  setControlsLocked(true);                     // khóa nút bắt đầu và ô nhập

  moveTarget();                                // đặt mục tiêu lần đầu
  restartMoveTimer();                          // cho mục tiêu tự đổi vị trí mỗi giây

  countdownId = setInterval(() => {            // mỗi 1 giây chạy hàm này
    timeLeft--;                                // giảm 1 giây
    timeEl.textContent = timeLeft;             // cập nhật hiển thị
    if (timeLeft <= 0) endGame();              // hết giờ thì kết thúc
  }, 1000);
}

// Kết thúc trò chơi: khóa mọi thao tác và hiện tổng điểm
function endGame() {
  running = false;                    // không còn chơi nữa
  clearInterval(countdownId);         // dừng đếm ngược
  clearInterval(moveId);              // dừng đổi vị trí mục tiêu
  target.style.display = 'none';      // ẩn mục tiêu
  colorBtn.disabled = true;           // khóa nút đổi màu
  playerBtn.disabled = true;          // khóa nút người chơi
  startBtn.disabled = true;           // khóa nút bắt đầu
  timeInput.disabled = true;          // khóa ô nhập thời gian
  overlay.innerHTML = 'Hết giờ!<br>Tổng điểm của bạn<br><strong>' + score + '</strong>'; // nội dung kết quả
  overlay.style.display = 'flex';     // hiện lớp phủ kết quả
}

// Click trúng mục tiêu: +1 điểm, đổi vị trí ngay
target.addEventListener('click', (e) => {
  e.stopPropagation();                // không cho sự kiện lan ra arena
  if (!running) return;               // hết giờ thì không tính điểm
  score++;                            // tăng điểm
  scoreEl.textContent = score;        // cập nhật điểm
  moveTarget();                       // đổi vị trí ngay lập tức
  restartMoveTimer();                 // tính lại 1 giây cho vị trí mới
});

// Tạo màu ngẫu nhiên dạng hsl rồi đổi nền arena
colorBtn.addEventListener('click', () => {
  const hue = Math.floor(Math.random() * 360);               // góc màu ngẫu nhiên 0-359
  arena.style.background = 'hsl(' + hue + ', 70%, 85%)';     // màu sáng để mục tiêu dễ nhìn
});

// Bấm nút Người chơi: hiện mã sinh viên
playerBtn.addEventListener('click', () => {
  playerInfo.textContent = 'Người chơi: ' + MA_SINH_VIEN;
});

// Bấm nút bắt đầu thì chạy hàm startGame
startBtn.addEventListener('click', startGame);
